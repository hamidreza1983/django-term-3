from django.contrib import admin
from .models import FrequentlyQuestions, ContactUs


admin.site.register(FrequentlyQuestions)
admin.site.register(ContactUs)

# Register your models here.
